<?php

// Разрешаем только POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    exit("Błąd wysyłania formularza.");
}

// Данные из формы
$firstName = trim($_POST['first_name'] ?? '');
$lastName  = trim($_POST['last_name'] ?? '');
$email     = trim($_POST['email'] ?? '');
$phone     = trim($_POST['phone'] ?? '');
$school    = trim($_POST['school'] ?? '');
$direction = trim($_POST['direction'] ?? '');
$message   = trim($_POST['message'] ?? '—');

// Проверка обязательных полей
if (!$firstName || !$lastName || !$email || !$phone) {
    exit("Nie wypełniono wszystkich wymaganych pól.");
}

// Настройки почты
$to = "oplp5270@gmail.com";
$subject = "Nowe zgłoszenie – CoffeeLand";

// HTML-письмо
$body = "
<!DOCTYPE html>
<html lang='pl'>
<head>
<meta charset='UTF-8'>
</head>
<body style='margin:0; padding:0; background:#f2f4f7; font-family:Arial, sans-serif;'>

<table width='100%' cellpadding='0' cellspacing='0' style='background:#f2f4f7; padding:30px 0;'>
<tr>
<td align='center'>

<table width='600' cellpadding='0' cellspacing='0' style='background:#ffffff; border-radius:14px; overflow:hidden; box-shadow:0 10px 30px rgba(0,0,0,0.08);'>

<tr>
<td style='background:linear-gradient(135deg,#6f4e37,#8b5e3c); padding:25px; color:#ffffff;'>
    <h1 style='margin:0; font-size:22px;'>CoffeeLand</h1>
    <p style='margin:5px 0 0; font-size:14px; opacity:0.9;'>
        Nowe zgłoszenie rekrutacyjne
    </p>
</td>
</tr>

<tr>
<td style='padding:30px;'>

<h2 style='margin-top:0; font-size:20px; color:#333333;'>
📄 Dane kandydata
</h2>

<table width='100%' cellpadding='0' cellspacing='0' style='font-size:14px;'>

<tr>
<td style='padding:10px 0; color:#666;'>Imię i nazwisko</td>
<td style='padding:10px 0; font-weight:bold; color:#222;'>
$firstName $lastName
</td>
</tr>

<tr>
<td style='padding:10px 0; color:#666;'>Email</td>
<td style='padding:10px 0; font-weight:bold;'>$email</td>
</tr>

<tr>
<td style='padding:10px 0; color:#666;'>Telefon</td>
<td style='padding:10px 0; font-weight:bold;'>$phone</td>
</tr>

<tr>
<td style='padding:10px 0; color:#666;'>Szkoła</td>
<td style='padding:10px 0; font-weight:bold;'>$school</td>
</tr>

<tr>
<td style='padding:10px 0; color:#666;'>Kierunek</td>
<td style='padding:10px 0; font-weight:bold;'>$direction</td>
</tr>

</table>

<div style='margin-top:30px; padding:20px; background:#f8f9fa; border-radius:10px;'>
    <h3 style='margin-top:0; font-size:16px; color:#333;'>💬 Wiadomość</h3>
    <p style='margin:0; color:#555; line-height:1.6;'>
        " . nl2br(htmlspecialchars($message)) . "
    </p>
</div>

</td>
</tr>

<tr>
<td style='background:#fafafa; padding:20px; text-align:center; font-size:12px; color:#999;'>
    Ten email został wysłany automatycznie z formularza rekrutacyjnego CoffeeLand.<br>
    Możesz bezpośrednio odpowiedzieć na tę wiadomość.
</td>
</tr>

</table>

</td>
</tr>
</table>

</body>
</html>
";

// Заголовки
$headers  = "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
$headers .= "From: CoffeeLand <support@coffeeland.online>\r\n";
$headers .= "Reply-To: $email\r\n";

// Envelope sender (КРИТИЧНО)
$additionalParams = "-f support@coffeeland.online";

// Отправка
if (mail($to, $subject, $body, $headers, $additionalParams)) {
    header("Location: rekrutacja.php?success=1");
    exit;
} else {
    exit("❌ Błąd wysyłania emaila.");
}
